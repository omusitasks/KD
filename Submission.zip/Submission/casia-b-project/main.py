# import os
# from kaggle.api.kaggle_api_extended import KaggleApi

# # Explicitly set the Kaggle JSON path
# os.environ['KAGGLE_CONFIG_DIR'] = r"C:\Users\omusi\Downloads\KD\casia-b-project"

# # Initialize Kaggle API
# api = KaggleApi()
# api.authenticate()

# # Download dataset into your project folder
# dataset_path = r"C:\Users\omusi\Downloads\KD\casia-b-project\dataset"
# os.makedirs(dataset_path, exist_ok=True)  # Ensure the directory exists

# # Download and extract dataset
# api.dataset_download_files('trnquanghuyn/casia-b', path=dataset_path, unzip=True)

# print("Download Complete! Dataset saved to:", dataset_path)




import os
import argparse
import torch
import numpy as np
from tqdm import tqdm

from data_extraction import SkeletonExtractor
from data_preprocessing import GaitDataPreprocessor
from gait_graph_model import GaitGraphModel, load_data_and_create_dataloaders, GaitGraphTrainer
from inference import GaitRecognitionSystem

def main():
    parser = argparse.ArgumentParser(description='Gait Recognition System using CASIA-B dataset')
    parser.add_argument('--mode', type=str, default='train', choices=['extract', 'preprocess', 'train', 'test', 'all'],
                        help='Operation mode: extract, preprocess, train, test, or all')
    parser.add_argument('--dataset_path', type=str, default='C:/Users/omusi/Downloads/KD/casia-b-project/dataset',
                        help='Path to the CASIA-B dataset')
    parser.add_argument('--skeleton_path', type=str, default='C:/Users/omusi/Downloads/KD/casia-b-project/skeleton_data',
                        help='Path to store/load skeleton data')
    parser.add_argument('--processed_path', type=str, default='C:/Users/omusi/Downloads/KD/casia-b-project/processed_data',
                        help='Path to store/load processed data')
    parser.add_argument('--model_path', type=str, default='C:/Users/omusi/Downloads/KD/casia-b-project/model_output',
                        help='Path to store/load model')
    parser.add_argument('--subjects', type=str, default='all',
                        help='Subjects to process (comma-separated list or "all")')
    parser.add_argument('--epochs', type=int, default=50,
                        help='Number of training epochs')
    parser.add_argument('--batch_size', type=int, default=32,
                        help='Batch size for training')
    parser.add_argument('--test_video', type=str, default=None,
                        help='Path to video for testing inference')
                        
    args = parser.parse_args()
    
    # Create directories if they don't exist
    os.makedirs(args.skeleton_path, exist_ok=True)
    os.makedirs(args.processed_path, exist_ok=True)
    os.makedirs(args.model_path, exist_ok=True)
    
    # Parse subjects
    if args.subjects == 'all':
        subjects = None
    else:
        subjects = args.subjects.split(',')
    
    # Extract skeleton data
    if args.mode in ['extract', 'all']:
        print("Extracting skeleton data...")
        extractor = SkeletonExtractor(args.dataset_path, args.skeleton_path)
        extractor.process_dataset(subject_ids=subjects)
    
    # Preprocess data
    if args.mode in ['preprocess', 'all']:
        print("Preprocessing data...")
        preprocessor = GaitDataPreprocessor(args.skeleton_path, args.processed_path)
        X_train, y_train, X_test, y_test = preprocessor.prepare_dataset()
    
    # Train model
    if args.mode in ['train', 'all']:
        print("Training model...")
        # Set device
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(f"Using device: {device}")
        
        # Load data and create dataloaders
        train_loader, test_loader = load_data_and_create_dataloaders(
            args.processed_path, batch_size=args.batch_size)
        
        # Create model
        num_joints = 16
        num_features = 4  # x, y, z, visibility
        hidden_channels = 128
        num_classes = 124  # Number of subjects in CASIA-B
        
        model = GaitGraphModel(num_joints, num_features, hidden_channels, num_classes)
        
        # Train model
        trainer = GaitGraphTrainer(model, device, args.model_path)
        trainer.train(train_loader, test_loader, num_epochs=args.epochs)
        
        # Generate report
        trainer.generate_report(test_loader)
    
    # Test model
    if args.mode == 'test':
        print("Testing model...")
        # Set device
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Load data and create dataloaders
        _, test_loader = load_data_and_create_dataloaders(
            args.processed_path, batch_size=args.batch_size)
        
        
        # Create model
        num_joints = 16
        num_features = 4  # x, y, z, visibility
        hidden_channels = 128
        num_classes = 124  # Number of subjects in CASIA-B
        
        model = GaitGraphModel(num_joints, num_features, hidden_channels, num_classes)
        model.load_state_dict(torch.load(os.path.join(args.model_path, 'best_model.pth'), 
                                          map_location=device))
        
        # Create trainer and generate report
        trainer = GaitGraphTrainer(model, device, args.model_path)
        trainer.generate_report(test_loader)
        
        # Test with a video if provided
        if args.test_video:
            system = GaitRecognitionSystem(os.path.join(args.model_path, 'best_model.pth'))
            subject_id = system.recognize_from_video(args.test_video)
            print(f"Identified subject: {subject_id}")

if __name__ == "__main__":
    main()