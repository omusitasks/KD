import os #edge_index
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv, global_mean_pool
from torch_geometric.data import Data, Dataset, DataLoader
from torch.optim import Adam
from tqdm import tqdm
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

# from gait_graph_model import GaitGraphDataset 

class GaitGraphModel(torch.nn.Module):
    def __init__(self, num_joints, num_features, hidden_channels, num_classes):
        super(GaitGraphModel, self).__init__()
        
        # Input feature dimensions: [frames*joints, features]
        self.num_joints = num_joints
        self.num_features = num_features
        
        # GNN layers
        self.conv1 = GCNConv(num_features, hidden_channels)
        self.conv2 = GCNConv(hidden_channels, hidden_channels)
        self.conv3 = GCNConv(hidden_channels, hidden_channels)
        
        # Classification head
        self.fc1 = torch.nn.Linear(hidden_channels, hidden_channels)
        self.fc2 = torch.nn.Linear(hidden_channels, num_classes)
        
        # Dropout for regularization
        self.dropout = torch.nn.Dropout(0.5)
        
    def forward(self, data):
        # Extract features and edge index
        x, edge_index = data.x, data.edge_index
        
        # Handle empty graphs or invalid edge indices
        if edge_index.numel() == 0:
            # No edges, return zeros
            batch_size = 1 if not hasattr(data, 'batch') else int(data.batch.max()) + 1
            return torch.zeros(batch_size, self.fc2.out_features, device=x.device)
        
        # Get batch information
        batch = data.batch if hasattr(data, 'batch') else torch.zeros(x.size(0), dtype=torch.long, device=x.device)
        
        # Apply GNN layers
        x = F.relu(self.conv1(x, edge_index))
        x = self.dropout(x)
        x = F.relu(self.conv2(x, edge_index))
        x = self.dropout(x)
        x = self.conv3(x, edge_index)
        
        # Global pooling - aggregate node features to get graph-level representation
        x = global_mean_pool(x, batch)
        
        # Classification
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.fc2(x)
        
        return x
    


class GaitGraphDataset(Dataset):
    """Custom dataset for GaitGraph data."""
    
    def __init__(self, features, labels):
        self.features = features
        self.labels = labels
        
    def __len__(self):
        return len(self.features)
    
    def __getitem__(self, idx):
        # Get features and label for this sample
        sequence = self.features[idx]  # Shape: [frames, joints*features]
        label = self.labels[idx]
        
        # Reshape to [frames, joints, features]
        num_joints = 16  # Number of key joints as defined in preprocessing
        num_features = 4  # x, y, z, visibility
        
        # Reshape and ensure we have the right dimensions
        sequence = sequence.reshape(sequence.shape[0], num_joints, num_features)
        
        # Flatten to [frames*joints, features]
        x = torch.FloatTensor(sequence.reshape(-1, num_features))
        
        # Total number of nodes in the graph (frames * joints)
        total_nodes = sequence.shape[0] * num_joints
        
        # Create edges between joints (spatial connections)
        edge_index = []
        
        # These define the connections between joints in the skeleton (using 0-based indexing)
        body_edges = [
            (0, 1),  # between shoulders
            (0, 6),  # left shoulder to left hip
            (1, 7),  # right shoulder to right hip
            (6, 7),  # between hips
            
            # Arms
            (0, 2), (2, 4),  # left arm
            (1, 3), (3, 5),  # right arm
            
            # Legs
            (6, 8), (8, 10), (10, 12), (12, 14),  # left leg
            (7, 9), (9, 11), (11, 13), (13, 15),  # right leg
        ]
        
        num_frames = sequence.shape[0]
        
        # Add spatial connections (within each frame)
        for frame_idx in range(num_frames):
            frame_offset = frame_idx * num_joints
            for j1, j2 in body_edges:
                # Make sure indices are valid
                if j1 < num_joints and j2 < num_joints:
                    # Add bidirectional edges
                    edge_index.append([frame_offset + j1, frame_offset + j2])
                    edge_index.append([frame_offset + j2, frame_offset + j1])
        
        # Add temporal connections (between consecutive frames)
        for frame_idx in range(num_frames - 1):
            current_frame_offset = frame_idx * num_joints
            next_frame_offset = (frame_idx + 1) * num_joints
            
            for joint_idx in range(num_joints):
                # Connect same joint across consecutive frames
                edge_index.append([current_frame_offset + joint_idx, next_frame_offset + joint_idx])
                edge_index.append([next_frame_offset + joint_idx, current_frame_offset + joint_idx])
        
        # Convert to torch tensor and ensure proper shape for PyG
        if edge_index:  # Check if we have any edges
            edge_index = torch.LongTensor(edge_index).t().contiguous()
            
            # Double-check for invalid indices
            if edge_index.max() >= total_nodes:
                print(f"WARNING: Invalid edge index found. Max index: {edge_index.max().item()}, total nodes: {total_nodes}")
                # Filter out invalid edges
                valid_mask = (edge_index[0] < total_nodes) & (edge_index[1] < total_nodes)
                edge_index = edge_index[:, valid_mask]
        else:
            # Create empty edge_index tensor if no edges
            edge_index = torch.zeros((2, 0), dtype=torch.long)
        
        # Create Data object
        data = Data(x=x, edge_index=edge_index, y=torch.tensor(label, dtype=torch.long))
        
        return data


class GaitGraphTrainer:
    def __init__(self, model, device, output_path):
        """
        Initialize the trainer.
        
        Args:
            model: GaitGraphModel instance
            device: Device to use for training (cpu or cuda)
            output_path: Path to save model and results
        """
        self.model = model.to(device)
        self.device = device
        self.output_path = output_path
        
        # Create output directory if it doesn't exist
        os.makedirs(output_path, exist_ok=True)
        
        # Initialize optimizer
        self.optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
        self.criterion = torch.nn.CrossEntropyLoss()
        
        # For tracking metrics
        self.train_losses = []
        self.test_accuracies = []
        self.best_accuracy = 0.0
    
    def train_epoch(self, train_loader):
        """Train for one epoch."""
        self.model.train()
        total_loss = 0
        
        for batch in tqdm(train_loader, desc="Training"):
            batch = batch.to(self.device)
            self.optimizer.zero_grad()
            
            output = self.model(batch)
            loss = self.criterion(output, batch.y)
            
            loss.backward()
            self.optimizer.step()
            
            total_loss += loss.item() * batch.num_graphs
        
        avg_loss = total_loss / len(train_loader.dataset)
        self.train_losses.append(avg_loss)
        return avg_loss
    
    def test(self, test_loader):
        """Evaluate the model."""
        self.model.eval()
        correct = 0
        total = 0
        
        with torch.no_grad():
            for batch in test_loader:
                batch = batch.to(self.device)
                output = self.model(batch)
                _, predicted = torch.max(output.data, 1)
                
                total += batch.y.size(0)
                correct += (predicted == batch.y).sum().item()
        
        accuracy = 100 * correct / total if total > 0 else 0
        self.test_accuracies.append(accuracy)
        return accuracy
    
    def train(self, train_loader, test_loader, num_epochs=50):
        """
        Train the model.
        
        Args:
            train_loader: DataLoader for training data
            test_loader: DataLoader for testing data
            num_epochs: Number of epochs to train
        """
        print(f"Starting training for {num_epochs} epochs")
        
        for epoch in range(num_epochs):
            # Train one epoch
            avg_loss = self.train_epoch(train_loader)
            
            # Evaluate
            accuracy = self.test(test_loader)
            
            print(f"Epoch {epoch+1}/{num_epochs}, Loss: {avg_loss:.4f}, Accuracy: {accuracy:.2f}%")
            
            # Save the best model
            if accuracy > self.best_accuracy:
                self.best_accuracy = accuracy
                torch.save(self.model.state_dict(), os.path.join(self.output_path, 'best_model.pth'))
                print(f"Model saved with accuracy: {accuracy:.2f}%")
        
        print("Training completed!")
        
        # Save the final model
        torch.save(self.model.state_dict(), os.path.join(self.output_path, 'final_model.pth'))
        
        # Plot and save metrics
        self.plot_metrics()
    
    def generate_report(self, test_loader):
        """
        Generate a report with performance metrics.
        
        Args:
            test_loader: DataLoader for testing data
        """
        # Make sure we're using the best model
        best_model_path = os.path.join(self.output_path, 'best_model.pth')
        if os.path.exists(best_model_path):
            self.model.load_state_dict(torch.load(best_model_path, map_location=self.device))
        
        self.model.eval()
        all_preds = []
        all_labels = []
        
        with torch.no_grad():
            for batch in test_loader:
                batch = batch.to(self.device)
                output = self.model(batch)
                _, predicted = torch.max(output.data, 1)
                
                all_preds.extend(predicted.cpu().numpy())
                all_labels.extend(batch.y.cpu().numpy())
        
        if len(all_labels) == 0:
            print("No test data available for evaluation.")
            return
        
        # Calculate metrics
        accuracy = 100 * np.mean(np.array(all_preds) == np.array(all_labels))
        
        # Save confusion matrix if we have multiple classes
        unique_labels = np.unique(all_labels)
        if len(unique_labels) > 1:
            cm = confusion_matrix(all_labels, all_preds)
            plt.figure(figsize=(10, 8))
            sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
            plt.xlabel('Predicted')
            plt.ylabel('True')
            plt.title('Confusion Matrix')
            plt.savefig(os.path.join(self.output_path, 'confusion_matrix.png'))
            plt.close()
        
        # Generate classification report
        if len(unique_labels) > 1:
            report = classification_report(all_labels, all_preds)
            with open(os.path.join(self.output_path, 'classification_report.txt'), 'w') as f:
                f.write(report)
        
        print(f"Test Accuracy: {accuracy:.2f}%")
        print(f"Report saved to {self.output_path}")
    
    def plot_metrics(self):
        """Plot and save training metrics."""
        plt.figure(figsize=(12, 5))
        
        plt.subplot(1, 2, 1)
        plt.plot(self.train_losses)
        plt.title('Training Loss')
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        
        plt.subplot(1, 2, 2)
        plt.plot(self.test_accuracies)
        plt.title('Test Accuracy')
        plt.xlabel('Epoch')
        plt.ylabel('Accuracy (%)')
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, 'training_metrics.png'))
        plt.close()



def load_data_and_create_dataloaders(data_path, batch_size=1):
    """
    Load preprocessed data and create PyTorch Geometric DataLoader objects.
    
    Args:
        data_path: Path to the preprocessed data
        batch_size: Batch size for training
        
    Returns:
        train_loader, test_loader: DataLoader objects for training and testing
    """
    # Load preprocessed data
    X_train = np.load(os.path.join(data_path, 'X_train.npy'))
    y_train = np.load(os.path.join(data_path, 'y_train.npy'))
    
    try:
        X_test = np.load(os.path.join(data_path, 'X_test.npy'))
        y_test = np.load(os.path.join(data_path, 'y_test.npy'))
    except FileNotFoundError:
        # Handle the case where test data might be empty
        print("Warning: Test data not found or empty. Creating empty test loader.")
        X_test = np.zeros((0, *X_train.shape[1:]))
        y_test = np.array([], dtype=np.int64)
    
    # Create graph datasets
    train_dataset = GaitGraphDataset(X_train, y_train)
    test_dataset = GaitGraphDataset(X_test, y_test)
    
    train_loader = DataLoader(
        train_dataset, 
        batch_size=min(batch_size, len(train_dataset)),  # Ensure batch size isn't larger than dataset
        shuffle=True
    )
    
    test_loader = DataLoader(
        test_dataset, 
        batch_size=min(batch_size, len(test_dataset)),  # Ensure batch size isn't larger than dataset 
        shuffle=False
    )
    
    return train_loader, test_loader


class GaitGraphDataset(Dataset):
    """Custom dataset for GaitGraph data."""
    
    def __init__(self, features, labels):
        self.features = features
        self.labels = labels
        
    def __len__(self):
        return len(self.features)
    
    def __getitem__(self, idx):
        # Get features and label for this sample
        sequence = self.features[idx]  # Shape: [frames, joints*features]
        label = self.labels[idx]
        
        # Reshape to [frames, joints, features]
        num_joints = 16  # Number of key joints as defined in preprocessing
        num_features = 4  # x, y, z, visibility
        
        # Reshape and ensure we have the right dimensions
        sequence = sequence.reshape(sequence.shape[0], num_joints, num_features)
        
        # Flatten to [frames*joints, features]
        x = torch.FloatTensor(sequence.reshape(-1, num_features))
        
        # Total number of nodes in the graph (frames * joints)
        total_nodes = sequence.shape[0] * num_joints
        
        # Create edges between joints (spatial connections)
        edge_index = []
        
        # These define the connections between joints in the skeleton (using 0-based indexing)
        body_edges = [
            (0, 1),  # between shoulders
            (0, 6),  # left shoulder to left hip
            (1, 7),  # right shoulder to right hip
            (6, 7),  # between hips
            
            # Arms
            (0, 2), (2, 4),  # left arm
            (1, 3), (3, 5),  # right arm
            
            # Legs
            (6, 8), (8, 10), (10, 12), (12, 14),  # left leg
            (7, 9), (9, 11), (11, 13), (13, 15),  # right leg
        ]
        
        num_frames = sequence.shape[0]
        
        # Add spatial connections (within each frame)
        for frame_idx in range(num_frames):
            frame_offset = frame_idx * num_joints
            for j1, j2 in body_edges:
                # Make sure indices are valid
                if j1 < num_joints and j2 < num_joints:
                    # Add bidirectional edges
                    edge_index.append([frame_offset + j1, frame_offset + j2])
                    edge_index.append([frame_offset + j2, frame_offset + j1])
        
        # Add temporal connections (between consecutive frames)
        for frame_idx in range(num_frames - 1):
            current_frame_offset = frame_idx * num_joints
            next_frame_offset = (frame_idx + 1) * num_joints
            
            for joint_idx in range(num_joints):
                # Connect same joint across consecutive frames
                edge_index.append([current_frame_offset + joint_idx, next_frame_offset + joint_idx])
                edge_index.append([next_frame_offset + joint_idx, current_frame_offset + joint_idx])
        
        # Convert to torch tensor and ensure proper shape for PyG
        if edge_index:  # Check if we have any edges
            edge_index = torch.LongTensor(edge_index).t().contiguous()
            
            # Double-check for invalid indices
            if edge_index.max() >= total_nodes:
                # Filter out invalid edges
                valid_mask = (edge_index[0] < total_nodes) & (edge_index[1] < total_nodes)
                edge_index = edge_index[:, valid_mask]
        else:
            # Create empty edge_index tensor if no edges
            edge_index = torch.zeros((2, 0), dtype=torch.long)
        
        # Create Data object
        data = Data(x=x, edge_index=edge_index, y=torch.tensor(label, dtype=torch.long))
        
        return data
    

    
def main():
    # Example usage
    processed_data_path = "C:/Users/omusi/Downloads/KD/casia-b-project/processed_data"
    output_path = "C:/Users/omusi/Downloads/KD/casia-b-project/model_output"
    
    # Set device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # Load data and create dataloaders
    train_loader, test_loader = load_data_and_create_dataloaders(processed_data_path)
    
    # Create model
    num_joints = 16
    num_features = 4  # x, y, z, visibility
    hidden_channels = 128
    num_classes = 124  # Number of subjects in CASIA-B
    
    model = GaitGraphModel(num_joints, num_features, hidden_channels, num_classes)
    
    # Train model
    trainer = GaitGraphTrainer(model, device, output_path)
    trainer.train(train_loader, test_loader, num_epochs=50)
    
    # Generate report
    trainer.generate_report(test_loader)

if __name__ == "__main__":
    main()