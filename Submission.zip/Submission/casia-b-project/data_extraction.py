import cv2
import os
import numpy as np
import mediapipe as mp
import json
from tqdm import tqdm

class SkeletonExtractor:
    def __init__(self, dataset_path, output_path):
        """
        Initialize the skeleton extractor.
        
        Args:
            dataset_path: Path to the CASIA-B dataset
            output_path: Path to store the extracted skeleton data
        """
        self.dataset_path = dataset_path
        self.output_path = output_path
        self.mp_pose = mp.solutions.pose
        self.pose = self.mp_pose.Pose(
            static_image_mode=False,
            model_complexity=2,
            enable_segmentation=False,
            min_detection_confidence=0.5
        )
        
        # Create output directory if it doesn't exist
        os.makedirs(output_path, exist_ok=True)
    
    def extract_skeleton_from_image(self, image_path):
        """
        Extract skeleton keypoints from a single image.
        
        Args:
            image_path: Path to the image
            
        Returns:
            keypoints: Dictionary containing keypoint coordinates
        """
        image = cv2.imread(image_path)
        if image is None:
            print(f"Failed to load image: {image_path}")
            return None
            
        # Convert the image to RGB for MediaPipe
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        # Process the image with MediaPipe
        results = self.pose.process(image_rgb)
        
        if not results.pose_landmarks:
            print(f"No pose detected in: {image_path}")
            return None
        
        # Extract keypoint coordinates
        keypoints = {}
        for idx, landmark in enumerate(results.pose_landmarks.landmark):
            keypoints[f"{idx}"] = {
                "x": landmark.x,
                "y": landmark.y,
                "z": landmark.z,
                "visibility": landmark.visibility
            }
        
        return keypoints
    
    def extract_skeleton_from_sequence(self, subject_id, condition, angle):
        """
        Extract skeleton keypoints from a sequence of images.
        
        Args:
            subject_id: Subject ID (e.g., '001')
            condition: Condition (e.g., 'nm-01', 'bg-01', 'cl-01')
            angle: Camera angle (e.g., '000', '018', '036')
            
        Returns:
            sequence_data: List of keypoints for each frame
        """
        sequence_path = os.path.join(self.dataset_path, 'output', subject_id, condition, angle)
        if not os.path.exists(sequence_path):
            print(f"Path does not exist: {sequence_path}")
            return None
        
        # Get all image files in the sequence
        image_files = [f for f in os.listdir(sequence_path) if f.endswith('.png')]
        image_files.sort()  # Ensure frames are in order
        
        sequence_data = []
        for img_file in image_files:
            img_path = os.path.join(sequence_path, img_file)
            keypoints = self.extract_skeleton_from_image(img_path)
            if keypoints:
                sequence_data.append({
                    "frame": img_file,
                    "keypoints": keypoints
                })
        
        return sequence_data
    
    def process_subject(self, subject_id):
        """
        Process all sequences for a subject.
        
        Args:
            subject_id: Subject ID (e.g., '001')
        """
        subject_path = os.path.join(self.dataset_path, 'output', subject_id)
        conditions = [d for d in os.listdir(subject_path) if os.path.isdir(os.path.join(subject_path, d))]
        
        subject_data = {}
        
        for condition in conditions:
            condition_path = os.path.join(subject_path, condition)
            angles = [d for d in os.listdir(condition_path) if os.path.isdir(os.path.join(condition_path, d))]
            
            condition_data = {}
            for angle in angles:
                print(f"Processing subject {subject_id}, condition {condition}, angle {angle}")
                sequence_data = self.extract_skeleton_from_sequence(subject_id, condition, angle)
                if sequence_data:
                    condition_data[angle] = sequence_data
            
            subject_data[condition] = condition_data
        
        # Save the subject data
        output_file = os.path.join(self.output_path, f"{subject_id}_skeleton.json")
        with open(output_file, 'w') as f:
            json.dump(subject_data, f)
        
        print(f"Saved skeleton data for subject {subject_id} to {output_file}")
    
    def process_dataset(self, subject_ids=None):
        """
        Process the entire dataset or specified subjects.
        
        Args:
            subject_ids: List of subject IDs to process. If None, process all subjects.
        """
        if subject_ids is None:
            subject_path = os.path.join(self.dataset_path, 'output')
            subject_ids = [d for d in os.listdir(subject_path) if os.path.isdir(os.path.join(subject_path, d))]
        
        for subject_id in tqdm(subject_ids, desc="Processing subjects"):
            self.process_subject(subject_id)

def main():
    # Example usage
    dataset_path = "C:/Users/omusi/Downloads/KD/casia-b-project/dataset"
    output_path = "C:/Users/omusi/Downloads/KD/casia-b-project/skeleton_data"
    
    extractor = SkeletonExtractor(dataset_path, output_path)
    
    # Process a subset of subjects for testing
    extractor.process_dataset(subject_ids=['001', '002'])
    
    # Process the entire dataset
    # extractor.process_dataset()

if __name__ == "__main__":
    main()