import os
import cv2
import torch
import numpy as np
import mediapipe as mp
from torch_geometric.data import Data
from tqdm import tqdm

from gait_graph_model import GaitGraphModel

class GaitRecognitionSystem:
    def __init__(self, model_path, num_classes=124, hidden_channels=128):
        """
        Initialize the gait recognition system.
        
        Args:
            model_path: Path to the trained model
            num_classes: Number of classes (subjects)
            hidden_channels: Number of hidden channels in the model
        """
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Initialize MediaPipe Pose
        self.mp_pose = mp.solutions.pose
        self.pose = self.mp_pose.Pose(
            static_image_mode=False,
            model_complexity=2,
            enable_segmentation=False,
            min_detection_confidence=0.5
        )
        
        # Define the key joints for gait analysis
        self.key_joints = [
            11, 12,  # shoulders
            13, 14,  # elbows
            15, 16,  # wrists
            23, 24,  # hips
            25, 26,  # knees
            27, 28,  # ankles
            29, 30,  # heels
            31, 32   # feet
        ]
        
        # Define skeleton graph structure
        self.edges = [
            # Torso
            (0, 1),  # left shoulder to right shoulder
            (0, 4),  # left shoulder to left hip
            (1, 5),  # right shoulder to right hip
            (4, 5),  # left hip to right hip
            
            # Arms
            (0, 2),  # left shoulder to left elbow
            (2, 3),  # left elbow to left wrist
            (1, 6),  # right shoulder to right elbow
            (6, 7),  # right elbow to right wrist
            
            # Legs
            (4, 8),  # left hip to left knee
            (8, 10),  # left knee to left ankle
            (10, 12),  # left ankle to left foot
            (10, 14),  # left ankle to left heel
            (5, 9),  # right hip to right knee
            (9, 11),  # right knee to right ankle
            (11, 13),  # right ankle to right foot
            (11, 15),  # right ankle to right heel
        ]
        
        # Create edge index for PyTorch Geometric
        self.edge_index = self._create_edge_index()
        
        # Create model
        num_joints = 16
        num_features = 4  # x, y, z, visibility
        self.model = GaitGraphModel(num_joints, num_features, hidden_channels, num_classes)
        
        # Load trained model
        self.model.load_state_dict(torch.load(model_path, map_location=self.device))
        self.model.to(self.device)
        self.model.eval()
    
    def _create_edge_index(self):
        """
        Create the edge index tensor for PyTorch Geometric.
        
        Returns:
            edge_index: Tensor of shape [2, num_edges*2]
        """
        edges = []
        for src, dst in self.edges:
            edges.append([src, dst])
            edges.append([dst, src])  # Add reverse edge
            
        edge_index = torch.tensor(edges, dtype=torch.long).t().contiguous()
        return edge_index
    
    def extract_skeleton_from_frame(self, frame):
        """
        Extract skeleton keypoints from a frame.
        
        Args:
            frame: Input frame
            
        Returns:
            keypoints: Dictionary containing keypoint coordinates
        """
        # Convert the frame to RGB for MediaPipe
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Process the frame with MediaPipe
        results = self.pose.process(frame_rgb)
        
        if not results.pose_landmarks:
            return None
        
        # Extract keypoint coordinates
        keypoints = {}
        for idx, landmark in enumerate(results.pose_landmarks.landmark):
            keypoints[f"{idx}"] = {
                "x": landmark.x,
                "y": landmark.y,
                "z": landmark.z,
                "visibility": landmark.visibility
            }
        
        return keypoints
    
    def normalize_skeleton(self, keypoints):
        """
        Normalize skeleton keypoints.
        
        Args:
            keypoints: Dictionary of keypoints
            
        Returns:
            normalized_keypoints: Normalized keypoints as a numpy array
        """
        # Extract key joints
        joints = []
        for joint_id in self.key_joints:
            joint = keypoints.get(str(joint_id))
            if joint:
                joints.append([joint["x"], joint["y"], joint["z"], joint["visibility"]])
            else:
                joints.append([0, 0, 0, 0])  # Missing joint
        
        joints = np.array(joints)
        
        # Calculate hip center (average of left and right hip)
        hip_left = keypoints.get("23")
        hip_right = keypoints.get("24")
        
        if hip_left and hip_right:
            hip_center_x = (hip_left["x"] + hip_right["x"]) / 2
            hip_center_y = (hip_left["y"] + hip_right["y"]) / 2
            hip_center_z = (hip_left["z"] + hip_right["z"]) / 2
            
            # Translate to make hip center the origin
            joints[:, 0] -= hip_center_x
            joints[:, 1] -= hip_center_y
            joints[:, 2] -= hip_center_z
            
            # Calculate scale factor (distance between shoulders)
            shoulder_left = keypoints.get("11")
            shoulder_right = keypoints.get("12")
            
            if shoulder_left and shoulder_right:
                scale = np.sqrt((shoulder_left["x"] - shoulder_right["x"])**2 + 
                              (shoulder_left["y"] - shoulder_right["y"])**2 + 
                              (shoulder_left["z"] - shoulder_right["z"])**2)
                
                if scale > 0:
                    joints[:, :3] /= scale
        
        return joints.flatten()
    
    def recognize_from_video(self, video_path, save_visualization=True):
        """
        Recognize the subject from a video.
        
        Args:
            video_path: Path to the video file
            save_visualization: Whether to save visualization
            
        Returns:
            subject_id: Recognized subject ID
        """
        # Open the video file
        cap = cv2.VideoCapture(video_path)
        
        if not cap.isOpened():
            print(f"Error: Could not open video {video_path}")
            return None
        
        # Get video properties
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        
        # Prepare for visualization
        if save_visualization:
            output_path = video_path.rsplit('.', 1)[0] + '_result.mp4'
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
        
        # Extract skeletons from frames
        skeleton_sequence = []
        
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        pbar = tqdm(total=total_frames, desc="Processing video frames")
        
        frame_idx = 0
        predictions = []
        
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            
            # Extract skeleton from frame
            keypoints = self.extract_skeleton_from_frame(frame)
            
            if keypoints:
                # Normalize skeleton
                normalized_skeleton = self.normalize_skeleton(keypoints)
                skeleton_sequence.append(normalized_skeleton)
                
                # Visualize skeleton
                if save_visualization:
                    self._draw_skeleton(frame, keypoints)
                
                # Predict if we have enough frames
                if len(skeleton_sequence) >= 50:
                    subject_id = self._predict_from_sequence(skeleton_sequence)
                    predictions.append(subject_id)
                    
                    # Draw prediction on frame
                    if save_visualization:
                        cv2.putText(frame, f"Subject: {subject_id}", (10, 30), 
                                   cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                    
                    # Remove oldest frame
                    skeleton_sequence.pop(0)
            
            # Save visualization
            if save_visualization:
                out.write(frame)
            
            frame_idx += 1
            pbar.update(1)
        
        pbar.close()
        cap.release()
        
        if save_visualization:
            out.release()
            print(f"Saved visualization to {output_path}")
        
        # Get the most frequent prediction
        if predictions:
            from collections import Counter
            counter = Counter(predictions)
            subject_id = counter.most_common(1)[0][0]
            return subject_id
        else:
            return None
    
    def _draw_skeleton(self, frame, keypoints):
        """
        Draw the skeleton on the frame.
        
        Args:
            frame: Input frame
            keypoints: Dictionary of keypoints
        """
        h, w = frame.shape[:2]
        
        # Draw points
        for joint_id in self.key_joints:
            joint = keypoints.get(str(joint_id))
            if joint and joint["visibility"] > 0.5:
                x = int(joint["x"] * w)
                y = int(joint["y"] * h)
                cv2.circle(frame, (x, y), 5, (0, 255, 0), -1)
        
        # Draw edges
        for src, dst in self.edges:
            src_joint = keypoints.get(str(self.key_joints[src]))
            dst_joint = keypoints.get(str(self.key_joints[dst]))
            
            if (src_joint and dst_joint and 
                src_joint["visibility"] > 0.5 and dst_joint["visibility"] > 0.5):
                src_x = int(src_joint["x"] * w)
                src_y = int(src_joint["y"] * h)
                dst_x = int(dst_joint["x"] * w)
                dst_y = int(dst_joint["y"] * h)
                
                cv2.line(frame, (src_x, src_y), (dst_x, dst_y), (0, 255, 0), 2)
    
    def _predict_from_sequence(self, skeleton_sequence):
        """
        Predict the subject ID from a sequence of skeletons.
        
        Args:
            skeleton_sequence: List of normalized skeletons
            
        Returns:
            subject_id: Predicted subject ID
        """
        # Ensure the sequence has 50 frames
        if len(skeleton_sequence) > 50:
            # Subsample if too long
            indices = np.linspace(0, len(skeleton_sequence) - 1, 50, dtype=int)
            skeleton_sequence = [skeleton_sequence[i] for i in indices]
        elif len(skeleton_sequence) < 50:
            # Pad with the last frame if too short
            last_frame = skeleton_sequence[-1]
            skeleton_sequence.extend([last_frame] * (50 - len(skeleton_sequence)))
        
        # Convert sequence to PyTorch Geometric data objects
        data_list = []
        for frame in skeleton_sequence:
            # Reshape frame data to [num_joints, num_features]
            frame_data = frame.reshape(16, 4)
            
            # Create PyTorch Geometric data object
            x = torch.tensor(frame_data, dtype=torch.float)
            
            data = Data(x=x, edge_index=self.edge_index)
            data_list.append(data)
        
        # Move data to device
        data_list = [data.to(self.device) for data in data_list]
        
        # Forward pass
        with torch.no_grad():
            outputs = self.model(data_list)
            _, predicted = torch.max(outputs, 1)
        
        # Convert to subject ID
        subject_id = predicted.item() + 1  # Add 1 because subject IDs start from 1
        
        return subject_id

def main():
    # Example usage
    model_path = "C:/Users/omusi/Downloads/KD/casia-b-project/model_output/best_model.pth"
    video_path = "C:/Users/omusi/Downloads/KD/casia-b-project/test_video.mp4"
    
    system = GaitRecognitionSystem(model_path)
    subject_id = system.recognize_from_video(video_path)
    print(f"Identified subject: {subject_id}")

if __name__ == "__main__":
    main()