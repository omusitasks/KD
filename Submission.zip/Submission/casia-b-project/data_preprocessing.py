import os
import json
import random
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from tqdm import tqdm

class GaitDataPreprocessor:
    def __init__(self, skeleton_data_path, output_path):
        """
        Initialize the gait data preprocessor.
        
        Args:
            skeleton_data_path: Path to the extracted skeleton data
            output_path: Path to store the preprocessed data
        """
        self.skeleton_data_path = skeleton_data_path
        self.output_path = output_path
        
        # Create output directory if it doesn't exist
        os.makedirs(output_path, exist_ok=True)
        
        # Define the key joints for gait analysis
        self.key_joints = [
            11, 12,  # shoulders
            13, 14,  # elbows
            15, 16,  # wrists
            23, 24,  # hips
            25, 26,  # knees
            27, 28,  # ankles
            29, 30,  # heels
            31, 32   # feet
        ]
        
    def normalize_skeleton(self, keypoints):
        """
        Normalize skeleton keypoints.
        
        Args:
            keypoints: Dictionary of keypoints
            
        Returns:
            normalized_keypoints: Normalized keypoints as a numpy array
        """
        # Extract key joints
        joints = []
        for joint_id in self.key_joints:
            joint = keypoints.get(str(joint_id))
            if joint:
                joints.append([joint["x"], joint["y"], joint["z"], joint["visibility"]])
            else:
                joints.append([0, 0, 0, 0])  # Missing joint
        
        joints = np.array(joints)
        
        # Calculate hip center (average of left and right hip)
        hip_left = keypoints.get("23")
        hip_right = keypoints.get("24")
        
        if hip_left and hip_right:
            hip_center_x = (hip_left["x"] + hip_right["x"]) / 2
            hip_center_y = (hip_left["y"] + hip_right["y"]) / 2
            hip_center_z = (hip_left["z"] + hip_right["z"]) / 2
            
            # Translate to make hip center the origin
            joints[:, 0] -= hip_center_x
            joints[:, 1] -= hip_center_y
            joints[:, 2] -= hip_center_z
            
            # Calculate scale factor (distance between shoulders)
            shoulder_left = keypoints.get("11")
            shoulder_right = keypoints.get("12")
            
            if shoulder_left and shoulder_right:
                scale = np.sqrt((shoulder_left["x"] - shoulder_right["x"])**2 + 
                               (shoulder_left["y"] - shoulder_right["y"])**2 + 
                               (shoulder_left["z"] - shoulder_right["z"])**2)
                
                if scale > 0:
                    joints[:, :3] /= scale
        
        return joints.flatten()
    
    def extract_features_from_sequence(self, sequence_data):
        """
        Extract features from a sequence of frames.
        
        Args:
            sequence_data: List of frame data with keypoints
            
        Returns:
            features: Array of features for the sequence
        """
        features = []
        for frame in sequence_data:
            normalized_keypoints = self.normalize_skeleton(frame["keypoints"])
            features.append(normalized_keypoints)
        
        # Ensure all sequences have the same length
        max_frames = 50  # Maximum number of frames to consider
        if len(features) > max_frames:
            # Subsample if too long
            indices = np.linspace(0, len(features) - 1, max_frames, dtype=int)
            features = [features[i] for i in indices]
        elif len(features) < max_frames:
            # Pad with zeros if too short
            last_frame = features[-1] if features else np.zeros(len(self.key_joints) * 4)
            features.extend([last_frame] * (max_frames - len(features)))
        
        return np.array(features)
    
    def process_subject_data(self, subject_id):
        """
        Process the data for a subject.
        
        Args:
            subject_id: Subject ID
            
        Returns:
            subject_features: Dictionary of features for each condition and angle
        """
        skeleton_file = os.path.join(self.skeleton_data_path, f"{subject_id}_skeleton.json")
        
        if not os.path.exists(skeleton_file):
            print(f"Skeleton file not found: {skeleton_file}")
            return None
        
        with open(skeleton_file, 'r') as f:
            subject_data = json.load(f)
        
        subject_features = {}
        
        for condition, condition_data in subject_data.items():
            # Skip empty conditions
            if not condition_data:
                continue
                
            condition_features = {}
            
            for angle, sequence_data in condition_data.items():
                # Skip empty sequences or angles
                if not sequence_data:
                    continue
                    
                features = self.extract_features_from_sequence(sequence_data)
                condition_features[angle] = features
            
            # Only add conditions that have data
            if condition_features:
                subject_features[condition] = condition_features
        
        return subject_features

    def prepare_dataset(self, train_subjects=None, test_subjects=None):
        """
        Prepare the dataset for training and testing.
        
        Args:
            train_subjects: List of subject IDs for training
            test_subjects: List of subject IDs for testing
            
        Returns:
            X_train, y_train, X_test, y_test: Training and testing data
        """
        # Get all subject IDs
        subject_files = [f for f in os.listdir(self.skeleton_data_path) if f.endswith('_skeleton.json')]
        all_subjects = [f.split('_')[0] for f in subject_files]
        
        if not all_subjects:
            raise ValueError("No subject data found. Please run the extraction step first.")
        
        # Split subjects if not provided
        if train_subjects is None or test_subjects is None:
            if len(all_subjects) > 1:
                train_subjects, test_subjects = train_test_split(all_subjects, test_size=0.2, random_state=42)
            else:
                # If only one subject, use it for both training and testing
                train_subjects = all_subjects
                test_subjects = all_subjects
                print("Warning: Only one subject found. Using same subject for training and testing.")
        
        X_train, y_train = [], []
        X_test, y_test = [], []
        
        # Process training subjects
        for subject_id in tqdm(train_subjects, desc="Processing training subjects"):
            features = self.process_subject_data(subject_id)
            if features:
                # Use normal walking conditions for training (nm-01 to nm-04)
                for condition in ['nm-01', 'nm-02', 'nm-03', 'nm-04']:
                    if condition in features:
                        for angle, angle_features in features[condition].items():
                            X_train.append(angle_features)
                            y_train.append(int(subject_id))
        
        # Process testing subjects
        for subject_id in tqdm(test_subjects, desc="Processing testing subjects"):
            features = self.process_subject_data(subject_id)
            if features:
                # For single subject case, make sure we have test data
                conditions_to_test = ['nm-05', 'nm-06', 'bg-01', 'bg-02', 'cl-01', 'cl-02']
                
                # Check if we have any of these conditions
                test_conditions = [c for c in conditions_to_test if c in features]
                
                # If no test conditions available, use some training data for testing
                if not test_conditions and len(all_subjects) == 1:
                    print("Warning: No separate test conditions found. Using some training data for testing.")
                    training_conditions = [c for c in ['nm-01', 'nm-02', 'nm-03', 'nm-04'] if c in features]
                    
                    if training_conditions:
                        # Use the last training condition for testing
                        test_condition = training_conditions[-1]
                        for angle, angle_features in features[test_condition].items():
                            X_test.append(angle_features)
                            y_test.append(int(subject_id))
                else:
                    # Use available test conditions
                    for condition in test_conditions:
                        if condition in features:
                            for angle, angle_features in features[condition].items():
                                X_test.append(angle_features)
                                y_test.append(int(subject_id))
        
        # If we still have no test data, split the training data
        if len(X_test) == 0 and len(X_train) > 0:
            print("Warning: No test data available. Splitting training data for testing.")
            if len(X_train) > 1:
                # Split if we have more than one sample
                train_indices = list(range(len(X_train)))
                test_size = max(1, int(len(X_train) * 0.2))
                test_indices = random.sample(train_indices, test_size)
                train_indices = [i for i in train_indices if i not in test_indices]
                
                X_test = [X_train[i] for i in test_indices]
                y_test = [y_train[i] for i in test_indices]
                X_train = [X_train[i] for i in train_indices]
                y_train = [y_train[i] for i in train_indices]
            else:
                # If only one sample, use it for both
                X_test = X_train.copy()
                y_test = y_train.copy()
        
        X_train = np.array(X_train)
        y_train = np.array(y_train)
        X_test = np.array(X_test)
        y_test = np.array(y_test)
        
        # Make sure we have some data to work with
        if len(X_train) == 0:
            raise ValueError("No training data available. Check your dataset and preprocessing.")
        if len(X_test) == 0:
            raise ValueError("No testing data available. Check your dataset and preprocessing.")
        
        # Save the processed data
        np.save(os.path.join(self.output_path, 'X_train.npy'), X_train)
        np.save(os.path.join(self.output_path, 'y_train.npy'), y_train)
        np.save(os.path.join(self.output_path, 'X_test.npy'), X_test)
        np.save(os.path.join(self.output_path, 'y_test.npy'), y_test)
        
        print(f"Saved processed data to {self.output_path}")
        print(f"Training data shape: {X_train.shape}, Testing data shape: {X_test.shape}")
        
        return X_train, y_train, X_test, y_test

def main():
    # Example usage
    skeleton_data_path = "C:/Users/omusi/Downloads/KD/casia-b-project/skeleton_data"
    output_path = "C:/Users/omusi/Downloads/KD/casia-b-project/processed_data"
    
    preprocessor = GaitDataPreprocessor(skeleton_data_path, output_path)
    
    # Process all subjects
    X_train, y_train, X_test, y_test = preprocessor.prepare_dataset()

if __name__ == "__main__":
    main()