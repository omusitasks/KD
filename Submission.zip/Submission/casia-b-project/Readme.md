# Gait Recognition System using CASIA-B Dataset

This project implements a gait recognition system that identifies people based on their walking style using the CASIA-B dataset. The system uses MediaPipe Pose for skeletal data extraction and a GaitGraph-based model for recognition.

## Project Structure

```
casia-b-project/
├── data_extraction.py    # Extracts skeleton data from CASIA-B dataset using MediaPipe
├── data_preprocessing.py # Preprocesses skeleton data for training
├── gait_graph_model.py   # Implements the GaitGraph model for gait recognition
├── inference.py          # Provides functions for real-time inference
├── main.py               # Main script to run the entire pipeline
├── requirements.txt      # Required dependencies
├── dataset/              # CASIA-B dataset
├── skeleton_data/        # Extracted skeleton data
├── processed_data/       # Preprocessed data ready for training
└── model_output/         # Trained models and evaluation results
```

## Installation

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/casia-b-project.git
   cd casia-b-project
   ```

2. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Install PyTorch Geometric (if not included in requirements.txt):
   ```
   pip install torch-geometric
   pip install torch-scatter torch-sparse -f https://data.pyg.org/whl/torch-2.0.0+cpu.html
   ```

## Dataset

This project uses the CASIA-B dataset, which should be structured as follows:
```
dataset/
  output/
    001/
      bg-01/
        000/
        018/
        ...
      bg-02/
      cl-01/
      ...
    002/
    ...
    124/
```

## Usage

### Data Extraction

Extract skeleton data from the CASIA-B dataset:
```
python main.py --mode extract --dataset_path C:/Users/omusi/Downloads/KD/casia-b-project/dataset --skeleton_path C:/Users/omusi/Downloads/KD/casia-b-project/skeleton_data
```

You can also process only specific subjects:
```
python main.py --mode extract --subjects 001,002,003
```

### Data Preprocessing

Preprocess the extracted skeleton data:
```
python main.py --mode preprocess
```

### Model Training

Train the GaitGraph model:
```
python main.py --mode train --epochs 50 --batch_size 32
```

### Testing/Inference

Test the trained model:
```
python main.py --mode test
```

Test with a video file:
```
python main.py --mode test --test_video path/to/video.mp4
```

### Run the Entire Pipeline

Run all steps in one command:
```
python main.py --mode all
```

## Model Architecture

The system uses a GaitGraph-based model that combines Graph Convolutional Networks (GCN) with LSTM for temporal modeling. The model processes skeleton sequences as graphs, where joints are nodes and limbs are edges.

## Performance

The model is evaluated based on:
- Classification accuracy
- Confusion matrix
- Detailed classification report

Results are saved in the `model_output` directory.

## Real-time Inference

The system can perform real-time inference on video files:
```
python inference.py --video path/to/video.mp4
```

## License

[Insert your license information here]